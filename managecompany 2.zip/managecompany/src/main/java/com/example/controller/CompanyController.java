package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.exceptions.MandatoryFields;
import com.example.exceptions.TurnOver;
import com.example.model.Company;
import com.example.services.CompanyService;
import com.example.validations.CompanyValidation;

@RestController
@RequestMapping("api/market/company") 
public class CompanyController {

	@Autowired
	CompanyService objcompanyservice;
	
	@Autowired
	CompanyValidation companyValidation;
	
	@GetMapping("/getcompanydetails/{code}")
	public  ResponseEntity<?> getcompanydetails(@PathVariable String code){
		Optional<Company> c = Optional.of(new Company());
		c = objcompanyservice.getcompanybycode(code);
		if(!c.isPresent()) {
			return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		}else {
			return new ResponseEntity<Company>(c.get(), HttpStatus.OK);
		}
	}
	
	
	@DeleteMapping("/deletecompany/{code}")
	public  ResponseEntity<?> DeleteCompany(@PathVariable String code){
		Optional<Company> c = Optional.of(new Company());
		c = objcompanyservice.getcompanybycode(code);
		if(c.isPresent()) {
			objcompanyservice.deletecompany(code);
			return new ResponseEntity<>(null, HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("No Company Found", HttpStatus.BAD_REQUEST);
		}
	}
	@GetMapping("/getcompanydetails")
	public  ResponseEntity<?> getcompanydetail(){
		List<Company> l  = objcompanyservice.getcompany();
		if(!(l.size() >0)) {
			return new ResponseEntity<List<Company>>(l, HttpStatus.NOT_FOUND);
		}else {
		return new ResponseEntity<List<Company>>(l, HttpStatus.OK);
		}
	}
	
	@PostMapping("/Register")
	public  ResponseEntity<?> RegisterCompany(@RequestBody Company Comp ){
		
		
		try {
			companyValidation.mandatoryField(Comp);
		}
		catch (MandatoryFields e) {
			return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
		}
		
		
		try {
			companyValidation.Turnovervalidation(Comp);
		}
		catch (TurnOver e) {
			return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
		}
		
		
		boolean b = objcompanyservice.registercompany(Comp);
		if(b == true)
		return new ResponseEntity<String>( HttpStatus.OK);
		else
		return new ResponseEntity<String>( HttpStatus.BAD_REQUEST);
	}
	
	@PutMapping("/UpdateCompany")
	public  ResponseEntity<?> UpdateCompany(@RequestBody Company Comp ){
		
		Optional<Company> c = Optional.of(new Company());
		c = objcompanyservice.getcompanybycode(Comp.getCompanycode());
		if(!c.isPresent()) {
			return new ResponseEntity<>("Company Not Found", HttpStatus.NOT_FOUND);
		}else {
			
		try {
			companyValidation.mandatoryField(Comp);
		}
		catch (MandatoryFields e) {
			return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
		}
		
		
		try {
			companyValidation.Turnovervalidation(Comp);
		}
		catch (TurnOver e) {
			return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
		}
		
		
		boolean b = objcompanyservice.updateCompany(Comp);
		System.out.println("after update company ");
		if(b == true)
		return new ResponseEntity<String>("Company Updated", HttpStatus.OK);
		else
		return new ResponseEntity<String>("issue in Company Update ", HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@GetMapping("/test")
	public static String test(){
		return "<h1>hello from inner <h1/>";
	}
}
