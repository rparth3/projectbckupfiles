package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.model.UserDto;

@RestController
@RequestMapping("/consumer")
public class ConsumingController {
	
	@GetMapping("/login")
	public ResponseEntity dologin(@RequestBody UserDto user) {
	
	String Url = "http://localhost:8082/auth/user/login";
	RestTemplate restTemplate = new RestTemplate();
	HttpEntity<UserDto> request = new HttpEntity<>(user);
	ResponseEntity<?> response = restTemplate
	  .exchange(Url, HttpMethod.POST, request, Map.class);

	  Map<String, String> map = new HashMap<String, String> ();
	 map =  (Map<String, String>) response.getBody();
	if(map.get("Token")!= null) {
	 return new ResponseEntity<>(map,HttpStatus.OK);
	}
	else
	{
		 return new ResponseEntity<>("Login Failed ",HttpStatus.BAD_REQUEST);
	}
	}
	
	
}
