package com.example.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.model.Company;
import com.example.model.Stock;
import com.example.services.CompanyService;
import com.example.services.StockService;

@RestController
@RequestMapping("api/market/stock")
public class StockController {

	@Autowired
	StockService stockservice;
	@Autowired
	CompanyService companyservice;
	@Autowired
	CompanyController companycontroller ;
	 
	@PostMapping("/AddStock") 
	
	public ResponseEntity<?> addstock(@RequestBody Stock stock){
		
		Optional<Company> c = Optional.of(new Company());
		c = companyservice.getcompanybycode(stock.getCompany_code_fk());
		if(!c.isPresent()) {
			return new ResponseEntity<>("Company Not Found", HttpStatus.NOT_FOUND);
		}
		else {
			
		
		Company comp = new Company();
		comp.setStockPrice(stock.getStockPrice());
		comp.setCompanyceo(c.get().getCompanyceo());
		comp.setCompanyname(c.get().getCompanyname());
		comp.setCompanyturnover(c.get().getCompanyturnover());
		comp.setCompanywebsite(c.get().getCompanywebsite());
		comp.setStockexchange(c.get().getStockexchange());
		comp.setCompanycode(stock.getCompany_code_fk());
		
		String Url = "http://localhost:8081/api/market/company/UpdateCompany";
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<Company> request = new HttpEntity<>(comp);
		ResponseEntity<?> response = restTemplate
		  .exchange(Url, HttpMethod.PUT, request, String.class);
		 
		

		boolean result = (stockservice.addstockprice(stock.getCompany_code_fk(), stock.getStockPrice()) 
				&&  response.getStatusCode() ==  HttpStatus.OK);
		
		if(result == true) {
			return new ResponseEntity<String>("Stock Price Added",HttpStatus.CREATED );
		}
		else
		{
		   return new ResponseEntity<String>("Issue in Price Upload",HttpStatus.BAD_REQUEST );
		}
	}
	}
	
}
