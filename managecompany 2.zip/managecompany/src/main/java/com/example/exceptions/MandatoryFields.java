package com.example.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseStatus;

@Component
@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "All Mandatory fields was not provided")
public class MandatoryFields extends Exception{
	
	public MandatoryFields ()  
    {  
        super("All Mandatory fields was not provided");  
    }  
	
}
