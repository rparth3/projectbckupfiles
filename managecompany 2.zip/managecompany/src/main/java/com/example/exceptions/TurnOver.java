package com.example.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseStatus;

@Component
@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Turnover not over 10 cr")

public class TurnOver extends Exception{
	
	public TurnOver ()  
    {  
        super("Turnover not over 10 cr");  
    }  
	
}
