package com.example.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Company {
	
	@Id
	private String companycode;
	private String companyname;
	private String companyceo; 
	private double companyturnover;
	private String companywebsite;
	private String stockexchange;
	private double stockPrice;
	@CreationTimestamp
	private Date dateandtime;
	
	
	

	public Date getDateandtime() {
		return dateandtime;
	}
	public void setDateandtime(Date dateandtime) {
		this.dateandtime = dateandtime;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCompanyceo() {
		return companyceo;
	}
	public void setCompanyceo(String companyceo) {
		this.companyceo = companyceo;
	}
	
	public double getCompanyturnover() {
		return companyturnover;
	}
	public void setCompanyturnover(double companyturnover) {
		this.companyturnover = companyturnover;
	}
	public String getCompanywebsite() {
		return companywebsite;
	}
	public void setCompanywebsite(String companywebsite) {
		this.companywebsite = companywebsite;
	}
	public String getStockexchange() {
		return stockexchange;
	}
	public void setStockexchange(String stockexchange) {
		this.stockexchange = stockexchange;
	}
	
	
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	
	
	@OneToMany(cascade = CascadeType.ALL, targetEntity = Stock.class)
    @JoinColumn(name="company_code_fk")
    private List<Stock> stockList;
	
	public List<Stock> getStockList() {
		return stockList;
	}
	public void setStockList(List<Stock> stockList) {
		this.stockList = stockList;
	}
	
	
	
	
	
}
