
package com.example.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Stock {
	
	
	
	@Id
    @GeneratedValue
    private long transactionId;
	@CreationTimestamp
    private Date updatedAt;
    private double stockPrice;
    private String company_code_fk;
    
    public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public String getCompany_code_fk() {
		return company_code_fk;
	}
	public void setCompany_code_fk(String company_code_fk) {
		this.company_code_fk = company_code_fk;
	}
	
	
	
	
	
	
}
