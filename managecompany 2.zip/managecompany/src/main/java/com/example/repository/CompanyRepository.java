package com.example.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.Company;

@Repository
@Transactional
public interface CompanyRepository extends JpaRepository<Company,String> {

	@Modifying
	@Query("update Company c set c.companyceo = :ceo , \n"
			+ "c.companyname = :companyname,\r\n"
			+ "c.companyturnover = :companyturnover,\r\n"
			+ "c.companywebsite = :companywebsite \r\n"
			+ "where c.companycode = :companycode")
	public void updatecompany(String ceo,String companyname,double companyturnover,String companywebsite, String companycode);
}
