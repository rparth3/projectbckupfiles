package com.example.services;

import java.util.List;
import java.util.Optional;

import com.example.model.Company;

public interface CompanyService {
	
	public boolean registercompany(Company company);
	public List<Company> getcompany();
	public Optional<Company> getcompanybycode(String code);
	public boolean deletecompany(String code);
	public boolean updateCompany(Company company);

	



}
