package com.example.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.example.model.Company;
import com.example.model.Stock;
import com.example.repository.CompanyRepository;
import com.example.repository.StockRepository;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	CompanyRepository objcompanyrepo;
	
	@Autowired
	StockRepository objstockrepo;
	
	public boolean registercompany(Company company){
		try {
		 objcompanyrepo.saveAndFlush(company);
		 return true;
		}
		catch(Exception ex){
			return false;
		}
	}
	public boolean updateCompany(Company company) {
		
		Company objcom = new Company();
		objcom.setCompanycode(company.getCompanycode());
		objcom.setCompanyceo(company.getCompanyceo());
		objcom.setCompanyname(company.getCompanyname());
		objcom.setCompanyturnover(company.getCompanyturnover());
		objcom.setCompanywebsite(company.getCompanywebsite());
		objcom.setStockPrice(company.getStockPrice());
		objcom.setStockexchange(company.getStockexchange()) ;
		objcom.setDateandtime(company.getDateandtime());
		try {
			objcompanyrepo.saveAndFlush(objcom);

		 //objcompanyrepo.updatecompany(company.getCompanyceo(),company.getCompanyname(),company.getCompanyturnover(),company.getCompanywebsite(),company.getCompanycode()
					// );
			 return true;
			}
			catch(Exception ex){
				return false;
		}
	}

	
	
	public List<Company> getcompany(){
		return objcompanyrepo.findAll();
	}
	
	public Optional<Company> getcompanybycode(String code){
		return objcompanyrepo.findById(code);
	}
	
	public boolean deletecompany(String code) {
		try {
		objcompanyrepo.deleteById(code);
		 return true;
		}
		catch(Exception ex){
			return false;
		}
	}


}
