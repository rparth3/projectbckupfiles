package com.example.services;

import org.springframework.stereotype.Component;

@Component
public interface StockService {
	
	public boolean addstockprice(String code, double price);

}
