package com.example.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Stock;
import com.example.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	StockRepository stockrepo;
	
	public boolean addstockprice(String code, double price){
		Stock s = new Stock();
		s.setStockPrice(price);
		s.setCompany_code_fk(code);
		stockrepo.save(s);
		return true;
	}
	
}
