package com.example.validations;

import org.springframework.stereotype.Component;

import com.example.exceptions.MandatoryFields;
import com.example.exceptions.TurnOver;
import com.example.model.Company;

@Component
public class CompanyValidation {
	
	
	
	public void mandatoryField(Company comp)throws MandatoryFields{
		
		System.out.println("mandatoryField");
		if(comp.getCompanyceo().equals(null)) {
			throw new MandatoryFields();
		}else if(comp.getCompanycode().equals(null)) {
			throw new MandatoryFields();
		}else if(comp.getCompanyname().equals(null)) {
			throw new MandatoryFields();
		}else if(comp.getCompanywebsite().equals(null)) {
			throw new MandatoryFields();
		}
		else if(comp.getCompanyturnover() == 0) {
			throw new MandatoryFields();
		}
		
	}

	public void Turnovervalidation(Company comp)throws TurnOver{
		
		if(comp.getCompanyturnover() < 100000000) {
			throw new TurnOver();
		}
		}

}
