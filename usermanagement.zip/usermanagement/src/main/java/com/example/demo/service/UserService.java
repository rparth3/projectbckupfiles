package com.example.demo.service;

import java.util.List;

import com.example.demo.model.User;

public interface UserService {
	public boolean validateUser(String username, String password) ;
	public User addUser(User user) ;
	public List<User> getAllUsers(); 
}
